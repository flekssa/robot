from motion.core import LedLamp
class LightController:
    ui = None
    LedLamp = None
    def __init__(self,ui):
        LightController.ui = ui
        LightController.LedLamp = LedLamp()
    @staticmethod
    def ColorShange (color=None):
        LightController.color_null()
        match(color):
            case 'blue':
                LightController.blue()
            case 'green':
                LightController.green()
            case 'yellow':
                LightController.yellow()
            case 'green':
                LightController.green()
            case _ :
                LightController.color_null()
    @staticmethod
    def color_null():
        if LightController.LedLamp:
            LightController.LedLamp.setLamp('0000')
        LightController.ui.label_8.setText("Выключен")
    @staticmethod
    def blue ():
        if LightController.LedLamp:
            LightController.LedLamp.setLamp('1000')
        LightController.ui.label_8.setText("Ожидает команды в нчальном положении")
    @staticmethod
    def green():
        if LightController.LedLamp:
            LightController.LedLamp.setLamp('0100')
        LightController.ui.label_8.setText("В работе")
    @staticmethod
    def yellow():
        if LightController.LedLamp:
            LightController.LedLamp.setLamp('0010')
        LightController.ui.label_8.setText("Пауза")
    @staticmethod
    def red():
        if LightController.LedLamp:
            LightController.LedLamp.setLamp('0001')
        LightController.ui.label_8.setText("Аварийная остановка")
