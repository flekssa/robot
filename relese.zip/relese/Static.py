class Static:
    mode = 1
    active = False
    paused = False