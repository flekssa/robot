from potock import Potock
from PyQt5.QtWidgets import QPushButton
from RobotController import RobotControler
from Static import Static as s
class ConditionController():
    ui= None
    def __init__(self,ui):
        ConditionController.ui = ui
        self.actived = False
        self.paused = False
        self.potock = None
        
    @staticmethod
    def start():
        if s.active== False:
            s.active= True
            print(1)
    @staticmethod
    def end():
        if s.active:
            s.active = False
    @staticmethod
    def pause():
        if s.active and s.paused:
            s.paused = False
        elif s.active and s.paused == False:
            s.paused = False
    @staticmethod
    def stop():
        if s.active:
            s.active == False

    def active(self,button:QPushButton):
        self.potock = Potock(button)
        self.potock.start()
 
    def relese(self):
        if self.potock and self.potock.is_start:
            self.potock.stop()        
    @staticmethod
    def mode():
        if s.mode == 0:
            RobotControler.robot_cart_mode()
        else:
            RobotControler.robot_join_mode()
    

    