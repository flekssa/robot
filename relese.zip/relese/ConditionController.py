from potock import Potock
from PyQt5.QtWidgets import QPushButton, QTableWidget, QTableWidgetItem
import math
from RobotController import RobotControler
from Static import Static as s
from lightControler import LightController 
from log import Log as l
class ConditionController():
    ui= None
    def __init__(self,ui):
        ConditionController.ui = ui
        self.actived = False
        self.paused = False
        self.potock = None
        
    @staticmethod
    def start():
        if s.active== False:
            s.active= True
            s.paused = False
            print(1)
            RobotControler.robot_engage()
            LightController.blue()
            l.log("info","The robot is enabled",ConditionController.ui.plainTextEdit)
    @staticmethod
    def end():
        if s.active:
            s.active = False
            RobotControler.robot_desengage()
            LightController.color_null()
            l.log("info","The robot is desenabled",ConditionController.ui.plainTextEdit_5)
    @staticmethod
    def pause():
        if s.active and s.paused:
            s.paused = False
            LightController.blue()
            l.log("info","The robot is pause",ConditionController.ui.plainTextEdit_3)
        elif s.active and s.paused == False:
            s.paused = True
            LightController.yellow()
            RobotControler.robot_to_start()

            
    @staticmethod
    def stop():
        if s.active:
            s.active == False
            LightController.red()
            l.log("info","emergency stop",ConditionController.ui.plainTextEdit_4)

    def active(self,button:QPushButton):
        if s.active and s.paused ==False and s.manual_mode:
            self.potock = Potock(button)
            self.potock.start()
            ConditionController.table_widget()
            LightController.green()
 
    def relese(self):
        if self.potock and self.potock.is_start:
            self.potock.stop()   
            LightController.blue()     
    @staticmethod
    def mode():
        if s.mode == 0:
            RobotControler.robot_cart_mode()
            s.mode = 1
            ConditionController.ui.move_button.setText("MoveJ")
        else:
            RobotControler.robot_join_mode()
            s.mode = 0 
            ConditionController.ui.move_button.setText("MoveC")
    @staticmethod
    def manual_mode():
        if s.manual_mode:
            s.manual_mode = False
        else:
            s.manual_mode = True
    @staticmethod
    def tool():
        position = RobotControler.robot_get_tool_position()
        if s.tool:
            s.tool = False
            ConditionController.ui.tool_button.setText("Открыть")
            a = ["3 ","4","4","5"]
            l.log("info",str(position),ConditionController.ui.plainTextEdit_7)
            l.log("info","gripper off",ConditionController.ui.plainTextEdit_7)
        else:
            s.tool = True
            ConditionController.ui.tool_button.setText("Закрыть")
            l.log("info",str(position),ConditionController.ui.plainTextEdit_7)
            l.log("info","gripper on",ConditionController.ui.plainTextEdit_7)

    def table_widget(self):
    

        #position = RobotControler.robot_get_tool_position()

        position = ["1","2","3"]

        coord1 = QTableWidgetItem(position[0])

        coord2 = QTableWidgetItem(position[1])

        coord3 = QTableWidgetItem(position[2])

        self.ui.tableWidget.setItem(0,0,coord1)

        self.ui.tableWidget.setItem(0,1,coord2)

        self.ui.tableWidget.setItem(0,2,coord3) 


        #ticks = RobotControler.robot_get_motor_tick()
        ticks = ["1","2","3","4","5","6"]
        

        j_tick = QTableWidgetItem(str(ticks[0]))

        j_tick2 = QTableWidgetItem(str(ticks[1]))

        j_tick3 = QTableWidgetItem(str(ticks[2]))

        j_tick4 = QTableWidgetItem(str(ticks[3])) 

        j_tick5 = QTableWidgetItem(str(ticks[4]))

        j_tick6 = QTableWidgetItem(str(ticks[5]))


        self.ui.tableWidget_2.setItem(2,0,j_tick)

        self.ui.tableWidget_2.setItem(2,1,j_tick2)

        self.ui.tableWidget_2.setItem(2,2,j_tick3) 

        self.ui.tableWidget_2.setItem(2,3,j_tick4) 

        self.ui.tableWidget_2.setItem(2,4,j_tick5) 

        self.ui.tableWidget_2.setItem(2,5,j_tick6) 

        #radiants = RobotControler.robot_get_motor_radiant()
        radiants = [1,2,4,5,6,7,8]

        j_radiant = QTableWidgetItem(str(radiants[0]))

        j_radiant2 = QTableWidgetItem(str(radiants[1]))

        j_radiant3 = QTableWidgetItem(str(radiants[2]))

        j_radiant4 = QTableWidgetItem(str(radiants[3]))

        j_radiant5 = QTableWidgetItem(str(radiants[4]))

        j_radiant6 = QTableWidgetItem(str(radiants[5]))

        self.ui.tableWidget_2.setItem(1,0,j_radiant)

        self.ui.tableWidget_2.setItem(1,1,j_radiant2)

        self.ui.tableWidget_2.setItem(1,2,j_radiant3) 

        self.ui.tableWidget_2.setItem(1,3,j_radiant4) 

        self.ui.tableWidget_2.setItem(1,4,j_radiant5) 

        self.ui.tableWidget_2.setItem(1,5,j_radiant6) 


        j_degrees = QTableWidgetItem(str((radiants[0] * 180) / math.pi))

        j_degrees2 = QTableWidgetItem(str((radiants[1] * 180) / math.pi))

        j_degrees3 = QTableWidgetItem(str((radiants[2] * 180) / math.pi))

        j_degrees4 = QTableWidgetItem(str((radiants[3] * 180) / math.pi))

        j_degrees5 = QTableWidgetItem(str((radiants[4] * 180) / math.pi))

        j_degrees6 = QTableWidgetItem(str((radiants[5] * 180) / math.pi))

        self.ui.tableWidget_2.setItem(0,0,j_degrees)

        self.ui.tableWidget_2.setItem(0,1,j_degrees2)

        self.ui.tableWidget_2.setItem(0,2,j_degrees3) 

        self.ui.tableWidget_2.setItem(0,3,j_degrees4) 

        self.ui.tableWidget_2.setItem(0,4,j_degrees5) 

        self.ui.tableWidget_2.setItem(0,5,j_degrees6)

        #temp = RobotControler.robot_get_motor_temerature()
        temp = ["1","2","3","4","5","6"]

        j_temp = QTableWidgetItem(str(temp[0]))

        j_temp2 = QTableWidgetItem(str(temp[1]))

        j_temp3= QTableWidgetItem(str(temp[2]))

        j_temp4 = QTableWidgetItem(str(temp[3]))

        j_temp5 = QTableWidgetItem(str(temp[4]))

        j_temp6 = QTableWidgetItem(str(temp[5]))

        self.ui.tableWidget_2.setItem(3,0,j_temp)

        self.ui.tableWidget_2.setItem(3,1,j_temp2)

        self.ui.tableWidget_2.setItem(3,2,j_temp3) 

        self.ui.tableWidget_2.setItem(3,3,j_temp4) 

        self.ui.tableWidget_2.setItem(3,4,j_temp5) 

        self.ui.tableWidget_2.setItem(3,5,j_temp6)
