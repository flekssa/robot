from potock import Potock
from PyQt5.QtWidgets import QPushButton
from RobotController import RobotControler
from Static import Static as s
from lightControler import LightController 
from log import Log as l
class ConditionController():
    ui= None
    def __init__(self,ui):
        ConditionController.ui = ui
        self.actived = False
        self.paused = False
        self.potock = None
        
    @staticmethod
    def start():
        if s.active== False:
            s.active= True
            s.paused = False
            print(1)
            RobotControler.robot_engage()
            LightController.blue()
            l.log("info","The robot is enabled",ConditionController.ui.plainTextEdit)
    @staticmethod
    def end():
        if s.active:
            s.active = False
            RobotControler.robot_desengage()
            LightController.color_null()
            l.log("info","The robot is desenabled",ConditionController.ui.plainTextEdit_5)
    @staticmethod
    def pause():
        if s.active and s.paused:
            s.paused = False
            LightController.blue()
            l.log("info","The robot is pause",ConditionController.ui.plainTextEdit_3)
        elif s.active and s.paused == False:
            s.paused = True
            LightController.yellow()

            
    @staticmethod
    def stop():
        if s.active:
            s.active == False
            LightController.red()
            l.log("info","emergency stop",ConditionController.ui.plainTextEdit_4)

    def active(self,button:QPushButton):
        if s.active and s.paused ==False and s.manual_mode:
            self.potock = Potock(button)
            self.potock.start()
            LightController.green()
 
    def relese(self):
        if self.potock and self.potock.is_start:
            self.potock.stop()   
            LightController.blue()     
    @staticmethod
    def mode():
        if s.mode == 0:
            RobotControler.robot_cart_mode()
            s.mode = 1
            ConditionController.ui.move_button.setText("MoveJ")
        else:
            RobotControler.robot_join_mode()
            s.mode = 0 
            ConditionController.ui.move_button.setText("MoveC")
    @staticmethod
    def manual_mode():
        if s.manual_mode:
            s.manual_mode = False
        else:
            s.manual_mode = True
    @staticmethod
    def tool():
        if s.tool:
            s.tool = False
            ConditionController.ui.tool_button.setText("Открыть")
            l.log("info","1",ConditionController.ui.plainTextEdit_7)
        else:
            s.tool = True
            ConditionController.ui.tool_button.setText("Закрыть")
            l.log("info","1",ConditionController.ui.plainTextEdit_7)
    