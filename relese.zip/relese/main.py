import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from MainWindow import MainWindow
def run ():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
run()