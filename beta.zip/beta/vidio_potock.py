from ultralytics import YOLO
import torch
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QLabel
import cv2
import time
from PyQt5.QtGui import QPixmap, QImage
from Static import Static as s
from motion.core import SmartCamera
class VideoPotock (QThread):
    person = pyqtSignal(int)
    camera = None
    def __init__(self, label: QLabel, interesting_classes):
        super().__init__()
        VideoPotock.camera = SmartCamera() 
        self.label = label
        self.model = YOLO("best.pt")
        self.clases = interesting_classes


    def run(self):
        cap = cv2.VideoCapture("video.mp4")

        while cap.isOpened():
            ret,frame = cap.read()
            if not ret:
                cap.release()                
                cap = cv2.VideoCapture("video.mp4")  
                continue
            frame = cv2.resize(frame,(500,500))
            box = frame
            
            if self.clases != [] and s.video == True:
                print(self.clases)
                result = self.model(frame,classes=self.clases)
                box = result[0].plot()
            if self.clases != [] and s.video == True:
                result1= self.model(frame,classes = self.clases[4])
                try:
                    id = int(result1[0].boxes.cls[0])
                    print(id)
                    self.person.emit(1)
                except:
                    self.person.emit(0)
            

            box = cv2.cvtColor(box,cv2.COLOR_BGR2RGB)
            img = QImage(box,box.shape[1], box.shape[0], QImage.Format_RGB888)
            pix = QPixmap.fromImage(img)
            self.label.setPixmap(pix)
            time.sleep(0.05)
        cap.release()
        print(self.clases)