from PyQt5.QtCore import QThread
from PyQt5.QtWidgets import QPushButton
from config import buttons_oces
from Static import Static as s
from RobotController import RobotControler
class Potock(QThread):
    def __init__(self, button: QPushButton):
        super().__init__()
        self.button = button.objectName()
        self.active = False
    def run(self):
        command = buttons_oces[self.button]
        massege = command['massege']
        move_command = command['command']
        self.active = True
        while self.active:
            if s.mode == 1:
                print(massege,s.mode)
                RobotControler.set_cart_velocity(move_command)
            else:
                print(massege,s.mode)
                RobotControler.set_join_Velocity(move_command)
    def stop (self):
        self.active = False
    def is_start(self):
        return self.active