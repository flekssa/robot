from Static import Static as s
from log import Log
from potock_B import Potock_B
from lightControler import LightController
from motion.robot_control.motion_program import Waypoint
from RobotController import RobotControler
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem
import datetime
class Comand_B():
    def __init__(self,ui):
        self.ui= ui
        self.commands =[]
        self.ui.pozition_button.clicked.connect(self.group1)
        self.ui.pozition_button_2.clicked.connect(self.group2)
        self.ui.pozition_button_3.clicked.connect(self.group3)
        self.ui.BRAK_button.clicked.connect(self.brack)
        self.ui.clear.clicked.connect(self.clear_comand)
        self.ui.del_pop.clicked.connect(self.del_pop)
        self.ui.run_button.clicked.connect(self.start_potock)
        self.waypoint_list =  []
        self.position = 0
        self.position2 = 0
        self.position3 = 0 
        self.position4 = 0
        self.potock = Potock_B(self.ui, self.commands,self.waypoint_list)
        self.cord1 = Waypoint([1.2,0,0,0,0,0])
        self.cord2 = Waypoint([0.5,0,0,0,0,0])
        self.cord3 = Waypoint([0.7,0,0,0,0,0])
        self.cord4 = Waypoint([0.9,0,0,0,0,0])
    def group1(self):
        if s.active and s.auto_mode:    
            self.commands.append("group 1")
            self.ui.plainTextEdit_2.appendPlainText("group 1")
            self.waypoint_list.append(self.cord1)
    def group2(self):
        if s.active and s.auto_mode: 
            self.commands.append("group 2")
            self.ui.plainTextEdit_2.appendPlainText("group 2")
            self.waypoint_list.append(self.cord2)
    def group3(self):
        if s.active and s.auto_mode: 
            self.commands.append("group 3")
            self.ui.plainTextEdit_2.appendPlainText("group 3")
            self.waypoint_list.append(self.cord3)
    def brack(self):
        if s.active and s.auto_mode: 
            self.commands.append("BRACK")
            self.ui.plainTextEdit_2.appendPlainText("BRACK")
            self.waypoint_list.append(self.cord4)
    def clear_comand(self):
        self.commands = []
        self.ui.plainTextEdit_2.setPlainText('')
        RobotControler.robot_reset()
        print(self.commands)
    def del_pop(self):
        try:
            self.commands.pop(0)
            text = self.ui.plainTextEdit_2.toPlainText().splitlines()
            if len(text)>0:
                del(text[-1])
                newtext='\n'.join(text)
                self.ui.plainTextEdit_2.setPlainText('')
                self.ui.plainTextEdit_2.appendPlainText(newtext)
        except:
            pass
    def start_potock(self):
        if self.commands != []:
            Log.log("info","The robot has started executing the program",self.ui.plainTextEdit_8)
            print(self.commands)
            self.potock = Potock_B(self.ui,self.commands,self.waypoint_list)
            self.potock.start()
            self.potock.log.connect(self.log)
            self.potock.light.connect(self.light)
            self.potock.status.connect(self.status)
        else:
            Log.log("info","The list for moving objects is empty",self.ui.plainTextEdit_8)
    def log(self, data):
        Log.log('info', data, self.ui.plainTextEdit_8)
    def light(self,color):
        LightController.ColorShange(color)
    def status (self,text,type):
        if type == 'group1':
            self.ui.label_18.setText(text)
            if text == 'Тара переполнина':
                self.ui.label_18.setStyleSheet('color: red')
            else:
                self.ui.label_18.setStyleSheet('color: black')
                self.position += 1

                coord1 = QTableWidgetItem(str(self.position))

                self.ui.tableWidget_3.setItem(0,0,coord1)

                time = str(datetime.datetime.now())

                time = QTableWidgetItem(str(time))
                self.ui.tableWidget_3.setItem(1,0,time)
                


        elif type == 'group2':
            self.ui.label_25.setText(text)
            if text == 'Тара переполнина':
                self.ui.label_25.setStyleSheet('color: red')
            else:
                self.ui.label_25.setStyleSheet('color: black')
                self.position2 += 1

                coord1 = QTableWidgetItem(str(self.position2))

                self.ui.tableWidget_3.setItem(0,1,coord1)

                time = str(datetime.datetime.now())

                time = QTableWidgetItem(str(time))
                self.ui.tableWidget_3.setItem(1,1,time)
                

        elif type == 'group3':
            self.ui.label_26.setText(text)
            if text == 'Тара переполнина':
                self.ui.label_26.setStyleSheet('color: red')
            else:
                self.ui.label_26.setStyleSheet('color: black')
                self.position3 += 1

                coord1 = QTableWidgetItem(str(self.position3))

                self.ui.tableWidget_3.setItem(0,2,coord1)

                time = str(datetime.datetime.now())

                time = QTableWidgetItem(str(time))
                self.ui.tableWidget_3.setItem(1,2,time)
        else:
            self.position4 += 1

            coord1 = QTableWidgetItem(str(self.position4))

            self.ui.tableWidget_3.setItem(0,3,coord1)
            time = str(datetime.datetime.now())

            time = QTableWidgetItem(str(time))
            self.ui.tableWidget_3.setItem(1,3,time)
       
                
