class Static:
    mode = 1
    active = False
    paused = False
    manual_mode = False
    tool = False
    auto_mode = False
    video = False
    human = []