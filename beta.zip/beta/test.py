from ultralytics import YOLO
import cv2
import numpy as np

# Загрузка модели YOLOv8
model = YOLO('best.pt')

# Список цветов для различных классов
model.names


