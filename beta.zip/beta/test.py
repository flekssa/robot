from math import radians

a = radians(10)
print(a)