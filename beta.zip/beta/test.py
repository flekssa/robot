from motion.core import RobotControl

class robot_():
    robot= None
    def __init__(self):
        robot_.robot = RobotControl()
    def connect_robot(velocity):
        if robot_.robot.connect():
            if robot_.robot.engage():
                robot_.robot.setCartesianVelocity(velocity)
