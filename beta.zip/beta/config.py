buttons_oces = {
     'plus_ose_6': {
         'massege': 'oce6_run',
         'command' : [0,0,0,0,0,0.1],
     },
     'plus_ose_5':{
       'massege': 'oce5_run',
        'command' : [0,0,0,0,0.1,0],
     },
     'plus_ose_4':{
       'massege': 'oce4_run',
        'command' : [0,0,0,0.1,0,0],

     },
     'plus_ose_3':{
       'massege': 'oce3_run',
       'command' : [0,0,0.1,0,0,0],
     },
     'plus_ose_2':{
       'massege': 'oce2_run',
       'command' : [0,0.1,0,0,0,0],
     },
     'plus_ose_1':{
       'massege': 'oce1_run',
       'command' : [0.1,0,0,0,0,0],
    },
    'pushButton_6':{
       'massege': 'oce6_run',
       'command' : [0,0,0,0,0,-0.1],
     },
    'pushButton_5':{
       'massege': 'oce5_run',
       'command' : [0,0,0,0,-0.1,0],

     },
    'pushButton_4':{
       'massege': 'oce4_run',
       'command' : [0,0,0,-0.1,0,0],
     },
    'pushButton_3':{
       'massege': 'oce3_run',
       'command' : [0,0,-0.1,0,0,0],
     },
    'pushButton_2':{
       'massege': 'oce2_run',
       'command' : [0,-0.1,0,0,0,0],
     },
    'pushButton':{
       'massege': 'oce1_run',
       'command' : [-0.1,0,0,0,0,0],
     }
}