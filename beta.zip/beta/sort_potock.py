from PyQt5.QtCore import QThread, pyqtSignal
from Static import Static as s
from RobotController import RobotControler
from math import radians
from motion.robot_control.motion_program import Waypoint
class Potock1(QThread):
    signal = pyqtSignal(str)
    def __init__(self):
        super().__init__()
        self.r1 = [0,0,radians(1),0,0,0]
        self.r1=Waypoint(self.r1)
        self.start_point = [radians(2),0,0,0,0,0]
        self.start_point= Waypoint(self.start_point)
        self.point = Waypoint([radians(3),0,0,0,0,0])
        self.start_point= [self.start_point ,self.r1]
        self.active = False
    def run(self):
        self.active = True
        while self.active:
            self.signal.emit("start")
            RobotControler.robot_to_start()
            RobotControler.robot_move_to_point(self.start_point)
            RobotControler.robot_to_start()
            RobotControler.robot_move_to_point(self.point)
            RobotControler.robot_to_start()
            self.signal.emit("finish")
            self.active = False
 
    def is_start(self):
        return self.active