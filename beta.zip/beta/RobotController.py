from motion.core import RobotControl 
from log import Log as l
class RobotControler:
     robot = None
     def __init__(self):
          RobotControler.robot = RobotControl(ip ="10.20.6.254")
     @staticmethod
     def robot_engage ():
          if RobotControler.robot:
               if RobotControler.robot.connect():
                    if RobotControler.robot.engage():
                         RobotControler.robot.manualCartMode()
     @staticmethod
     def set_join_Velocity(velocity):
          if RobotControler.robot:
               RobotControler.robot.setJointVelocity(velocity)
     @staticmethod
     def set_cart_velocity(velocity):
          if RobotControler.robot:
               RobotControler.robot.setCartesianVelocity(velocity)
     @staticmethod
     def robot_desengage():
          if RobotControler.robot:
               RobotControler.robot.disengage()
     @staticmethod
     def robot_pause():
          if RobotControler.robot:
                    RobotControler.robot.pause()
     @staticmethod
     def robot_stop():
          if RobotControler.robot:
                    RobotControler.robot.stop()
     @staticmethod
     def robot_join_mode():
          if RobotControler.robot:
               RobotControler.robot.manualJointMode()
     @staticmethod
     def robot_cart_mode():
          if RobotControler.robot:
               RobotControler.robot.manualCartMode()
     @staticmethod
     def robot_toolON():
          if RobotControler.robot:
               RobotControler.robot.toolON()
     @staticmethod
     def robot_toolOFF():
          if RobotControler.robot:
               RobotControler.robot.toolOFF()
     @staticmethod
     def robot_to_start():
          if RobotControler.robot:
               RobotControler.robot.moveToInitialPose()
     @staticmethod
     def robot_get_tool_position ():
          if RobotControler.robot:
               RobotControler.robot.getToolPosition()
     @staticmethod
     def robot_get_motor_tick():
          if RobotControler.robot:
               RobotControler.robot.getMotorPositionTick()
     @staticmethod
     def robot_get_motor_radiant():
          if RobotControler.robot:
               RobotControler.robot.getMotorPositionRadians()
     @staticmethod
     def robot_get_motor_temerature():
          if RobotControler.robot:
               RobotControler.robot.getActualTemperature()
     @staticmethod
     def robot_move_to_point(waypoint_list):
          if RobotControler.robot:
               RobotControler.robot.addMoveToPointJ(waypoint_list)
     @staticmethod
     def robot_play():
          if RobotControler.robot:
               RobotControler.robot.play()
     @staticmethod
     def robot_reset():
          if RobotControler.robot:
               RobotControler.robot.reset()
    