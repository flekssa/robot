from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow
from ConditionController import ConditionController
from lightControler import LightController
from log import Log as l
from RobotController import RobotControler
from Static import Static as s
from comand_B import Comand_B 
class MainWindow (QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("test2.ui", self)
        self.conditionController = ConditionController(self)
        LightController(self)
        self.log = l(self)
        self.potock = None
        self.start_button.clicked.connect(ConditionController.start)
        self.pause_button.clicked.connect(ConditionController.pause)
        self.speed_stop_button.clicked.connect(ConditionController.stop)
        self.end_button.clicked.connect(ConditionController.end)
        self.go_to_start_button.clicked.connect(RobotControler.robot_to_start)
        self.comand_B = Comand_B(self)

        self.plus_ose_6.pressed.connect(lambda checked = False, btn=self.plus_ose_6: self.conditionController.active(btn))
        self.plus_ose_6.released.connect(self.conditionController.relese)

        self.pushButton_6.pressed.connect(lambda checked = False, btn=self.pushButton_6: self.conditionController.active(btn))
        self.pushButton_6.released.connect(self.conditionController.relese)

        self.plus_ose_5.pressed.connect(lambda checked = False, btn=self.plus_ose_5: self.conditionController.active(btn))
        self.plus_ose_5.released.connect(self.conditionController.relese)

        self.pushButton_5.pressed.connect(lambda checked = False, btn=self.pushButton_5: self.conditionController.active(btn))
        self.pushButton_5.released.connect(self.conditionController.relese)

        self.plus_ose_4.pressed.connect(lambda checked = False, btn=self.plus_ose_4: self.conditionController.active(btn))
        self.plus_ose_4.released.connect(self.conditionController.relese)

        self.pushButton_4.pressed.connect(lambda checked = False, btn=self.pushButton_4: self.conditionController.active(btn))
        self.pushButton_4.released.connect(self.conditionController.relese)

        self.plus_ose_3.pressed.connect(lambda checked = False, btn=self.plus_ose_3:self.conditionController.active(btn))
        self.plus_ose_3.released.connect(self.conditionController.relese)

        self.pushButton_3.pressed.connect(lambda checked = False, btn=self.pushButton_3: self.conditionController.active(btn))
        self.pushButton_3.released.connect(self.conditionController.relese)

        self.plus_ose_2.pressed.connect(lambda checked = False, btn=self.plus_ose_2: self.conditionController.active(btn))
        self.plus_ose_2.released.connect(self.conditionController.relese)

        self.pushButton_2.pressed.connect(lambda checked = False, btn=self.pushButton_2: self.conditionController.active(btn))
        self.pushButton_2.released.connect(self.conditionController.relese)

        self.plus_ose_1.pressed.connect(lambda checked = False, btn=self.plus_ose_1: self.conditionController.active(btn))
        self.plus_ose_1.released.connect(self.conditionController.relese)

        self.pushButton.pressed.connect(lambda checked = False, btn=self.pushButton: self.conditionController.active(btn))
        self.pushButton.released.connect(self.conditionController.relese)

        self.move_button.clicked.connect(self.conditionController.mode)
        self.manualmode_button.clicked.connect(self.conditionController.manual_mode)
        self.tool_button.clicked.connect(self.conditionController.tool)


        self.pushButton_7.clicked.connect(self.log.log_save)
        self.conditionController.table_widget()
        
