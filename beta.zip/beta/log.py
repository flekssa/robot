import datetime
import os
import pandas as pd

class Log():
    ui = None
    def __init__(self,ui):
        Log.ui = ui
    @staticmethod
    def log(type,data,show_log):
        time = str(datetime.datetime.now())
        message = time + " " + type + " " + data
        show_log.appendPlainText(message)

    def log_save(self):
        directory = Log.ui.textEdit.toPlainText()
        message = Log.ui.plainTextEdit.toPlainText() + '\n' + Log.ui.plainTextEdit_3.toPlainText() +'\n'+ Log.ui.plainTextEdit_4.toPlainText() + '\n' + Log.ui.plainTextEdit_5.toPlainText()+ '\n' + Log.ui.plainTextEdit_6.toPlainText()+ '\n' + Log.ui.plainTextEdit_7.toPlainText() + '\n'
        if directory:
            file_log = os.path.join(directory,"log.txt")
            try:
                with open(file_log,'a') as file:
                    file.write("\n" + message + "\n")
                    file.close()
            except:
                pass
            df = pd.read_csv(file_log, header=None,  encoding='ISO-8859-1', names=["a", "b", "c", "d"])
            a= os.path.join(directory,"log.xlsx")
            df.to_excel(a, index=False,header=None)
            os.remove(file_log)

