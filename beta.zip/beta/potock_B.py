from PyQt5.QtCore import QThread, pyqtSignal
import time
from RobotController import RobotControler
from motion.robot_control.motion_program import Waypoint

class Potock_B (QThread):
    log = pyqtSignal(str)
    light = pyqtSignal(str)
    status = pyqtSignal(str,str)
    def __init__(self,ui,commands,waypoint_list):
        super().__init__()
        self.ui = ui
        self.waypoint_list= waypoint_list
        self.section_1 = 0
        self.section_2 = 0
        self.section_3 = 0
        self.commands = commands
        self.clear = False
        self.ui.tara_free.clicked.connect(self.clear_tara)
        self.timer = 0
        self.r1=Waypoint([0,0,-0.2,0,0,0])
        self.start_point= Waypoint([2,0,0,0,0,0])
       
        
    def run (self):
        while self.timer != 5:
            while self.commands != []:
                self.timer = 0
                self.light.emit('green')
                if self.commands[0] == 'group 1':
                    
                        if self.section_1 < 4:
                            RobotControler.robot_move_to_point(self.start_point)
                            RobotControler.robot_move_to_point(self.r1)
                            RobotControler.robot_to_start()
                            RobotControler.robot_move_to_point(self.waypoint_list[0])
                            RobotControler.robot_move_to_point(self.r1)
                            a=RobotControler.robot_get_tool_position()
                            self.log.emit(str(a)+"pozition tool")
                            self.status.emit('Тара пуста','group1')
                            self.section_1 +=1
                            print(self.section_1)
                            time.sleep(0.5)
                            self.commands.pop(0)
                            print("перенос окончен")
                            a="Group 1 object moved to the cell" + str(self.section_1)
                            self.log.emit(a)
                        else:
                            self.status.emit('Тара переполнина', 'group1')
                            self.light.emit('yellow')
                            RobotControler.robot_pause()
                            while not self.clear: pass
                            RobotControler.robot_play()
                            self.clear=False
                            self.section_1 = 0
                    
                elif self.commands[0] == 'group 2':
                    try:
                        if self.section_2 < 4:

                            RobotControler.robot_move_to_point(self.start_point)
                            RobotControler.robot_move_to_point(self.r1)
                            RobotControler.robot_to_start()
                            RobotControler.robot_move_to_point(self.waypoint_list[0])
                            RobotControler.robot_move_to_point(self.r1)
                            self.status.emit('Тара пуста','group2')
                            self.section_2 +=1
                            time.sleep(0.5)
                            self.commands.pop(0)
                            print("перенос окончен")
                            a="Group 2 object moved to the cell" + str(self.section_2)
                            self.log.emit(a)
                            
                        else:
                            self.status.emit('Тара переполнина', 'group2')
                            self.light.emit('yellow')
                            RobotControler.robot_pause()
                            while not self.clear: pass
                            RobotControler.robot_play()
                            self.clear=False
                            self.section_2 = 0


                    except:
                        print("ошибка")
                elif self.commands[0] == 'group 3':
                    try:
                        if self.section_3 < 4:
                            RobotControler.robot_move_to_point(self.start_point)
                            RobotControler.robot_move_to_point(self.r1)
                            RobotControler.robot_to_start()
                            RobotControler.robot_move_to_point(self.waypoint_list[0])
                            RobotControler.robot_move_to_point(self.r1)
                            self.status.emit('Тара пуста','group3')
                            self.section_3 +=1
                            print(self.section_3)
                            time.sleep(0.5)
                            self.commands.pop(0)
                            print("перенос окончен")
                            a="Group 3 object moved to the cell" + str(self.section_3)
                            self.log.emit(a)
                        else:
                            self.status.emit('Тара переполнина', 'group3')
                            self.light.emit('yellow')
                            RobotControler.robot_pause()
                            while not self.clear: pass
                            RobotControler.robot_play()
                            self.clear=False
                            self.section_3 = 0

                    except:
                        print("ошибка")
                elif self.commands[0] == 'BRACK':
                            RobotControler.robot_move_to_point(self.start_point)
                            RobotControler.robot_move_to_point(self.r1)
                            RobotControler.robot_to_start()
                            RobotControler.robot_move_to_point(self.waypoint_list[0])
                            RobotControler.robot_move_to_point(self.r1)
                            self.status.emit("brack",'brack')
                            print('Перенос в секцию BRACK')
                            time.sleep(0.5)
                            print('Перенос окончен')
                            self.commands.pop(0)
                            a= "The object has been moved to BRACK"
                            self.log.emit(a)
            
            RobotControler.robot_to_start()
            if self.commands == []:
                time.sleep(1)
                self.timer += 1
                print(self.timer,"if")
                self.light.emit('blue')


        a= "The robot has finished executing the program"
        RobotControler.robot_to_start()
        self.log.emit(a)
        self.light.emit('blue')
    def clear_tara(self):
        self.clear = True