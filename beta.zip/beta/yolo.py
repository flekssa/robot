from vidio_potock import VideoPotock
from Static import Static as s
import threading
class Yolov26():
    ui= None
    def __init__(self,ui):
        Yolov26.ui = ui
        self.interesting_classes = [0,1,2,4,5,6,7]
        Yolov26.ui.checkBox.stateChanged.connect(self.group1)
        Yolov26.ui.checkBox_2.stateChanged.connect(self.group2)
        Yolov26.ui.checkBox_3.stateChanged.connect(self.group3)
        Yolov26.ui.checkBox_4.stateChanged.connect(self.group4)
        Yolov26.ui.checkBox_5.stateChanged.connect(self.group5)
        Yolov26.ui.checkBox_6.stateChanged.connect(self.group6)
        Yolov26.ui.checkBox_7.stateChanged.connect(self.group7)
        Yolov26.ui.checkBox_8.stateChanged.connect(self.humman)
       
        self.video = VideoPotock(Yolov26.ui.vidio,self.interesting_classes)
       

    def group1(self,state):
        if state == 2:
            self.interesting_classes.append(0)
            s.think.append(0)
            print(self.interesting_classes)
        else:
            self.interesting_classes.remove(0)
            print(self.interesting_classes)
            s.think.append(0)
    def group2(self,state):
        if state == 2:
            self.interesting_classes.append(1)
            print(self.interesting_classes)
            s.think.append(0)
        else:
            self.interesting_classes.remove(1)
    def group3(self,state):
        if state == 2:
            self.interesting_classes.append(2)
            print(self.interesting_classes)
            s.think.append(0)
        else:
            self.interesting_classes.remove(2)  
            s.think.append(0)  

    def group4(self,state):
        if state == 2:
            self.interesting_classes.append(3)
            s.think.append(0)
        else:
            self.interesting_classes.remove(3)
            s.think.append(0)
    def group5(self,state):
        if state == 2:
            self.interesting_classes.append(7)
            s.think.append(0)
        else:
            self.interesting_classes.remove(7)
            s.think.append(0)
    def group6(self,state):
        if state == 2:
            self.interesting_classes.append(5)
            s.think.append(0)
        else:
            self.interesting_classes.remove(5)
            s.think.append(0)
    def group7(self,state):
        if state == 2:
            self.interesting_classes.append(6)
            s.think.append(0)
        else:
            self.interesting_classes.remove(6)
            s.think.append(0)
        
    def humman(self,state):
        if state == 2:
            s.human.append(4)
            self.interesting_classes.append(4)
        else:
            s.human.remove(4)
            self.interesting_classes.remove(4)

